"""Count the four categories specified in the supplied exercise (Python 3)."""
from pathlib import Path
import argparse
import hashlib
import json
import time

import numpy as np
import pandas as pd

LABELS = ["매우 나쁨", "나쁨", "보통", "좋음"]


def solve(data_dir, output_dir, device="cpu"):
    started = time.perf_counter()
    data_dir, output_dir = Path(data_dir), Path(output_dir)
    source = data_dir / "india-airquality.csv"
    frame = pd.read_csv(source, encoding="ISO-8859-1", low_memory=False)
    values = frame["pm2_5"].dropna().to_numpy(dtype=np.float64, copy=True)
    assert np.isfinite(values).all(), "Non-finite pollution value"
    bounds = np.array([16.0, 36.0, 76.0])
    boundary_values = np.array([15.999, 16, 16.001, 35.999, 36, 36.001, 75.999, 76, 76.001])
    expected_bins = np.array([0, 1, 1, 1, 2, 2, 2, 3, 3])
    compute_started = time.perf_counter()
    if device.startswith("cuda"):
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        tensor = torch.as_tensor(values, dtype=torch.float64, device=device)
        edges = torch.as_tensor(bounds, dtype=torch.float64, device=device)
        bins = torch.bucketize(tensor, edges, right=True)
        counts = torch.bincount(bins, minlength=4).flip(0).cpu().numpy()
        actual_bins = torch.bucketize(torch.as_tensor(boundary_values, device=device), edges, right=True).cpu().numpy()
        gpu_name = torch.cuda.get_device_name(torch.device(device))
    elif device == "cpu":
        counts = np.bincount(np.searchsorted(bounds, values, side="right"), minlength=4)[::-1]
        actual_bins = np.searchsorted(bounds, boundary_values, side="right")
        gpu_name = None
    else:
        raise ValueError(f"Unsupported device: {device}")
    compute_seconds = time.perf_counter() - compute_started
    np.testing.assert_array_equal(actual_bins, expected_bins)
    # Independent Boolean-rule reference, including exact lower bounds.
    reference = np.array([(values >= 76).sum(), ((values >= 36) & (values < 76)).sum(),
                          ((values >= 16) & (values < 36)).sum(), (values < 16).sum()])
    np.testing.assert_array_equal(counts, reference)
    sample = pd.read_csv(data_dir / "finedust_count(sample).csv")
    result = pd.DataFrame({"예보 등급": LABELS, "count": counts.astype(np.int64)})
    assert list(result.columns) == list(sample.columns) == ["예보 등급", "count"]
    assert result["예보 등급"].tolist() == sample["예보 등급"].tolist() == LABELS
    assert int(result["count"].sum()) == len(values)
    output_dir.mkdir(parents=True, exist_ok=True)
    destination = output_dir / "finedust_count.csv"
    result.to_csv(destination, index=False, encoding="utf-8")
    pd.testing.assert_frame_equal(pd.read_csv(destination), result)
    audit = {"passed": True, "device": device, "gpu_name": gpu_name,
             "input_rows": len(frame), "valid_rows": len(values),
             "dropped_missing_rows": int(frame["pm2_5"].isna().sum()),
             "counts": dict(zip(LABELS, counts.tolist())),
             "boundary_tests": len(boundary_values), "independent_reference_matched": True,
             "compute_seconds_including_device_initialization": compute_seconds,
             "elapsed_seconds": time.perf_counter() - started,
             "input_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
             "csv_sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}
    (output_dir / "validation.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    return result, audit


def run_harness(ctx):
    """Deterministic custom task: score is a rule check, not model accuracy."""
    result, audit = solve(ctx.cfg["data_root"], ctx.output / ctx.stage, ctx.device)
    ctx.publish(result, 1.0, {"algorithm": "specified_threshold_count", "feature_mode": "custom",
                             "score_meaning": "independent rule and CSV checks passed", **audit},
                artifacts={"validation.json": ctx.output / ctx.stage / "validation.json"})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    result, audit = solve(args.data_dir, args.output_dir, args.device)
    print(result.to_string(index=False))
    print(json.dumps(audit, ensure_ascii=False, indent=2))
