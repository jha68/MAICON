# -*- coding: utf-8 -*-
"""
auto_drive_tiki_ver6_yolo_dashboard.py

- 기존 레거시 주행 코드 그대로 유지
- QR 기능 모두 제거
- YOLO 객체 탐지 추가 (yolo_inference.py)
- DashboardComm를 이용한 탐지 보고 추가 (dashboard_comm.py)
"""

import cv2
import numpy as np
import time
import os
import ipywidgets as widgets
from math import atan
from IPython.display import display

from tiki.mini import TikiMini
from aruco_tag_action_tiki_final import ArucoTrigger

# === 추가된 모듈 ===
from yolo_inference import YOLOONNX
from dashboard_comm import DashboardComm


# =========================================================
# 디버그 UI 4개 (원본 / BEV / Binary / Sliding)
# =========================================================
w1 = widgets.Image(format='jpeg')
w2 = widgets.Image(format='jpeg')
w3 = widgets.Image(format='jpeg')
w4 = widgets.Image(format='jpeg')

display(w1, w2, w3, w4)

def to_bytes(img):
    _, buf = cv2.imencode('.jpg', img, [int(cv2.IMWRITE_JPEG_QUALITY), 40])
    return buf.tobytes()


# =========================================================
# BEV 변환
# =========================================================
def warpping(image):
    src = np.float32([
        [70, 230], [0,420], [570,230], [640,420]
    ])
    dst = np.float32([
        [0,0], [0,480], [480,0], [480,480]
    ])

    M = cv2.getPerspectiveTransform(src, dst)
    warp = cv2.warpPerspective(image, M, (480,480))
    return warp


# =========================================================
# 흰색 중앙선 필터
# =========================================================
def white_lane_filter(bev_bgr):
    hls = cv2.cvtColor(bev_bgr, cv2.COLOR_BGR2HLS)
    white_low  = np.array([0,170,0])
    white_high = np.array([180,255,255])
    mask = cv2.inRange(hls, white_low, white_high)
    kernel = np.ones((5,5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    return mask


# =========================================================
# Sliding Window (변경 없음)
# =========================================================
def sliding_window(binary_img):
    h, w = binary_img.shape
    binary = binary_img.copy()
    binary[:, :80] = 0
    binary[:, 400:] = 0

    nonzero = binary.nonzero()
    total_pix = len(nonzero[0])

    histogram = np.sum(binary[h//2:, :], axis=0)
    if np.max(histogram) == 0 or total_pix < 50:
        out = np.dstack((binary,binary,binary))
        return None, [], [], out

    x_current = np.argmax(histogram)
    nwindows = 18
    margin = 60
    minpix = 20
    window_height = h // nwindows

    out = np.dstack((binary,binary,binary))
    xs, ys = [], []

    for win in range(nwindows):
        wy_low = h - (win+1)*window_height
        wy_high= h - win*window_height
        wx_low = x_current - margin
        wx_high= x_current + margin

        cv2.rectangle(out,(wx_low,wy_low),(wx_high,wy_high),(0,255,0),2)

        good = (
            (nonzero[0]>=wy_low)&(nonzero[0]<wy_high)&
            (nonzero[1]>=wx_low)&(nonzero[1]<wx_high)
        ).nonzero()[0]

        if len(good) > minpix:
            x_current = int(np.mean(nonzero[1][good]))
            out[nonzero[0][good], nonzero[1][good]] = [255,0,0]

        xs.append(x_current)
        ys.append((wy_low+wy_high)/2)

    if len(xs) < 4:
        return None, xs, ys, out

    fit = np.polyfit(ys, xs, 2)

    yy = np.linspace(0, h-1, h)
    xx = np.polyval(fit, yy)
    for y,x in zip(yy.astype(int), xx.astype(int)):
        if 0<=x<w:
            out[y,x] = (0,255,255)

    return fit, xs, ys, out


# =========================================================
# Lane Follower (기존 그대로)
# =========================================================
class LaneFollower:

    def __init__(self, tiki, aruco_trigger):

        self.tiki = tiki
        self.aruco = aruco_trigger

        self.forward_rpm = 127
        self.rotate_gain = 25

        self.lat_weight = 1.5
        self.heading_weight = 0.4

        self.dbg_bev = None
        self.dbg_bin = None
        self.dbg_slide = None

        self.prev_xs = None
        self.intersection_countdown = 0

    def detect_intersection(self, xs):
        if len(xs)<6: return False

        xs = np.array(xs,dtype=np.float32)
        tail = xs[:6]
        dx = np.diff(tail)
        dx_abs = np.abs(dx)

        if np.max(dx_abs) > 80 and np.mean(dx_abs) > 25:
            return True

        if self.prev_xs is not None:
            prev_tail = np.array(self.prev_xs[:6],dtype=np.float32)
            if len(prev_tail)==len(tail):
                diff_prev = np.abs(tail - prev_tail)
                if np.max(diff_prev) > 90:
                    return True
        return False

    def follow(self, frame):

        bev = warpping(frame)
        self.dbg_bev = bev.copy()

        mask = white_lane_filter(bev)
        self.dbg_bin = mask.copy()

        fit, xs, ys, slide_img = sliding_window(mask)
        self.dbg_slide = slide_img
        self.prev_xs = xs

        if fit is None:
            return

        # 교차로 감지
        if self.detect_intersection(xs):
            self.intersection_countdown = 10

        # 직진 모드
        if self.intersection_countdown > 0:
            self.intersection_countdown -= 1

            # 시각화 파란선
            h,w,_ = self.dbg_slide.shape
            poly = np.poly1d(fit)
            yy = np.linspace(0,h-1,h)
            xx = np.polyval(poly,yy)
            for y,x in zip(yy.astype(int),xx.astype(int)):
                if 0<=x<w:
                    self.dbg_slide[y,x]=(255,0,0)

            self.tiki.set_motor_power(self.tiki.MOTOR_LEFT,40)
            self.tiki.set_motor_power(self.tiki.MOTOR_RIGHT,40)
            return

        # 일반 곡선 조향
        poly = np.poly1d(fit)
        heading = atan(poly[1])
        lane_x_bottom = np.polyval(fit,470)
        distance = -(lane_x_bottom - 240)
        lat_norm = distance/240.0

        curve_strength = abs(poly[1])
        if curve_strength > 0.003:
            base = 20
        else:
            base = self.forward_rpm

        total_err = self.lat_weight*lat_norm + self.heading_weight*heading
        steer = np.clip(total_err,-1.0,1.0)

        delta = int(abs(steer)*self.rotate_gain)

        if steer > 0.05:
            left = base - delta
            right= base + delta
        elif steer < -0.05:
            left = base + delta
            right= base - delta
        else:
            left=right=base

        self.tiki.set_motor_power(self.tiki.MOTOR_LEFT,int(left))
        self.tiki.set_motor_power(self.tiki.MOTOR_RIGHT,int(right))


# =========================================================
# Main
# =========================================================
def main():

    tiki = TikiMini()
    tiki.set_motor_mode(tiki.MOTOR_MODE_PID)
    tiki.stop()

    # -------------------------------
    # YOLO 모델 초기화
    # -------------------------------
    yolo_model = None
    yolo_path = "yolo/best.onnx"

    if os.path.exists(yolo_path):
        try:
            yolo_model = YOLOONNX(
                onnx_path=yolo_path,
                conf_threshold=0.4,
                iou_threshold=0.45
            )
            print("[MAIN] YOLO 로드 완료")
        except Exception as e:
            print(f"[MAIN] YOLO 로드 실패 : {e}")
    else:
        print(f"[MAIN] YOLO 파일 없음: {yolo_path}")

    # -------------------------------
    # DashboardComm 초기화
    # -------------------------------
    dashboard = None
    try:
        dashboard = DashboardComm(
            server_url="http://58.229.150.23:5000",
            mission_code="2W9G"
        )
        print("[MAIN] Dashboard 연결 성공")
    except Exception as e:
        print(f"[MAIN] Dashboard 초기화 실패: {e}")
        dashboard = None

    # -------------------------------
    # ArUco (기존 코드 그대로)
    # -------------------------------
    aruco = ArucoTrigger(
        tiki,
        straight_rpm=40,
        turn_rpm=40,
        # QR 제거했기 때문에 YOLO/대시보드를 넣지 않음
    )

    follower = LaneFollower(tiki, aruco)

    # -------------------------------
    # 카메라
    # -------------------------------
    pipeline = (
        "nvarguscamerasrc ! "
        "video/x-raw(memory:NVMM), width=640, height=480, format=NV12, framerate=6/1 ! "
        "nvvidconv ! video/x-raw, format=BGRx ! "
        "videoconvert ! video/x-raw, format=BGR ! appsink"
    )
    cap = cv2.VideoCapture(pipeline,cv2.CAP_GSTREAMER)

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            frame = cv2.flip(frame,-1)

            # -------------------------------
            # YOLO 객체 탐지 + Dashboard 보고
            # -------------------------------
            if yolo_model:
                detections = yolo_model.detect(frame)

                if dashboard and detections:
                    # YOLO detection format: [{'class':'fire', 'conf':0.8, 'bbox':(x1,y1,x2,y2)}, ...]
                    for det in detections:
                        cls = det['class']
                        conf = det['conf']
                        dashboard.add_detection(cls, float(conf))

            # -------------------------------
            # ArUco → 액션
            # -------------------------------
            aruco.observe_and_maybe_trigger(frame)

            # -------------------------------
            # 라인 추종
            # -------------------------------
            follower.follow(frame)

            # -------------------------------
            # ArUco 액션 step
            # -------------------------------
            aruco.step()

            # 디버그 화면
            w1.value = to_bytes(frame)
            if follower.dbg_bev is not None:
                w2.value = to_bytes(follower.dbg_bev)
            if follower.dbg_bin is not None:
                w3.value = to_bytes(follower.dbg_bin)
            if follower.dbg_slide is not None:
                w4.value = to_bytes(follower.dbg_slide)

            time.sleep(0.01)

    except KeyboardInterrupt:
        print("STOP")

    finally:
        tiki.stop()
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
